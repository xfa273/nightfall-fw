%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-09-21T03:40:24+09:00*%
%TF.ProjectId,HM_Nightfall-mini-2e_Encoder-PCB-R_v1,484d5f4e-6967-4687-9466-616c6c2d6d69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-09-21 03:40:24*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,0.600000X1.200000*%
%ADD11RoundRect,0.101600X-0.300000X-0.350000X0.300000X-0.350000X0.300000X0.350000X-0.300000X0.350000X0*%
%ADD12RoundRect,0.101600X0.350000X0.450000X-0.350000X0.450000X-0.350000X-0.450000X0.350000X-0.450000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,EC_R2*%
X148022100Y-108203600D03*
%TD*%
%TO.C,EC_R4*%
X149721100Y-108203600D03*
%TD*%
D11*
%TO.C,R2*%
X148030100Y-102209600D03*
X149030100Y-102209600D03*
%TD*%
D10*
%TO.C,EC_R1*%
X147281100Y-108203600D03*
%TD*%
D12*
%TO.C,C2*%
X149180100Y-104495600D03*
X147880100Y-104495600D03*
%TD*%
D10*
%TO.C,EC_R3*%
X148961900Y-108203600D03*
%TD*%
M02*
